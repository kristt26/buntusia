# jQuery LoadingOverlay

A flexible loading overlay jQuery plugin

---

Documentation and examples at https://gasparesganga.com/labs/jquery-loading-overlay/

